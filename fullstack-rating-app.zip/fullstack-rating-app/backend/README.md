# Backend

Run:
npm install
npm run start
