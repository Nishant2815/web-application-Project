function App() {
  return (
    <div>
      <h1>FullStack Rating App</h1>
    </div>
  );
}

export default App;
