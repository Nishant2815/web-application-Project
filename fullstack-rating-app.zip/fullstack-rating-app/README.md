# FullStack Store Rating Project

Tech Stack:
- ReactJS
- NestJS
- MySQL

Features:
- JWT Authentication
- Role Based Access
- Store Ratings
- Admin Dashboard
